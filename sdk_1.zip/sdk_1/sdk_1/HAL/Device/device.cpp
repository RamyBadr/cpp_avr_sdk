/*
 * device.cpp
 *
 * Created: 24/09/2018 11:28:11 PM
 *  Author: Ramy Badr
 */ 
