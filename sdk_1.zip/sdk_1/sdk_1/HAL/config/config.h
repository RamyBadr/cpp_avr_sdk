/*
 * config.h
 *
 * Created: 25/09/2018 08:47:05 PM
 *  Author: www
 */ 


#ifndef CONFIG_H_
#define CONFIG_H_
using namespace HAL;
namespace HAL{
	
}




#endif /* CONFIG_H_ */