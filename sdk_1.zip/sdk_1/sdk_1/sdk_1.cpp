/*
 * sdk_1.cpp
 *
 * Created: 23/09/2018 12:25:17 PM
 *  Author: Ramy Badr
 */ 

//#define TEST1_Run
#define TEST2
#include "HAL/test/test1.h"
#include "HAL/test/test2.h"
