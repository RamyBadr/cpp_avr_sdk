/*
 * Interrupt_Consts.h
 *
 * Created: 26/09/2018 04:11:44 AM
 *  Author: www
 */ 


#ifndef INTERRUPT_CONSTS_H_
#define INTERRUPT_CONSTS_H_
using namespace MCAL;
namespace MCAL{
	
}






#endif /* INTERRUPT_CONSTS_H_ */